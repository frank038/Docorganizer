#!/bin/bash

thisdir=$(dirname "$0")
cd $thisdir
./docorganizer.py
